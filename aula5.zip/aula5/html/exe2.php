<!DOCTYPE html>
<html>
<head>
	<title>Exercicio 02</title>
</head>
<body>

<?php

echo " Digite um valor: ";

$valor = 50;

if($valor == 10){

	echo $valor, " ,O valor e igual a 10.";
}
if($valor > 10){

	echo $valor, " ,O valor e maior que 10.";

}
else{
	echo $valor, " ,O valor e menor que 10.";
}


?>

</body>
</html>