<!DOCTYPE html>
<html>
<head>
	<title>Exercicio 03</title>
</head>
<body>

<?php 

echo " Digite um valor: ";

$valor = 50;

if($valor == 0){

	echo $valor, " ,O valor e igual a 0.";
}
if($valor > 0){

	echo $valor, " ,O valor e positivo.";

}
else{
	echo $valor, " ,O valor e negativo.";
}



?>

</body>
</html>