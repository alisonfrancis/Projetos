
<!DOCTYPE html>
<html>
<head>
	<title>PHP</title>
</head>
<body>
<?php

echo "Aula lp-IV";
 

$v =  text  ;

echo  "<hr> $v";

$n1 = 1;
$n2 = 1;

$r = $n1+$n2;



echo "<br> $r";

?>
</body>
</html>
